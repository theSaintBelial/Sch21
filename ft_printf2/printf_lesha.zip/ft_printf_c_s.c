
#include "ft_printf.h"

void	ft_print_c(char c, t_options *opts)
{
	if (opts->minus)
		ft_putchar(c, opts);
	if (opts->width--)
		while (opts->width--)
			ft_putchar(' ', opts);
	if (!(opts->minus))
		ft_putchar(c, opts);
}
